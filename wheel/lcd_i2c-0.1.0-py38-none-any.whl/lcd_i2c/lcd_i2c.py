#!/usr/bin/python
#--------------------------------------
#    ___  ___  _ ____
#   / _ \/ _ \(_) __/__  __ __
#  / , _/ ___/ /\ \/ _ \/ // /
# /_/|_/_/  /_/___/ .__/\_, /
#                /_/   /___/
#
#  lcd_i2c.py
#  LCD test script using I2C backpack.
#  Supports 16x2 and 20x4 screens.
#
# Author : Matt Hawkins
# Date   : 20/09/2015
#
# http://www.raspberrypi-spy.co.uk/
#
# Copyright 2015 Matt Hawkins
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#--------------------------------------
import time
import smbus

# Define some device parameters
I2C_ADDR = 0x27 # I2C device address
LCD_WIDTH_20 = 20   # Maximum characters per line for 20x4
LCD_WIDTH_16 = 16   # Maximum characters per line for 16x4

# Define some device constants
LCD_CHR = 1 # Mode - Sending data
LCD_CMD = 0 # Mode - Sending command

LCD_LINE_1 = 0x80 # LCD RAM address for the 1st line
LCD_LINE_2 = 0xC0 # LCD RAM address for the 2nd line
LCD_LINE_3 = 0x94 # LCD RAM address for the 3rd line
LCD_LINE_4 = 0xD4 # LCD RAM address for the 4th line

LCD_BACKLIGHT = 0x08  # On
#LCD_BACKLIGHT = 0x00  # Off

ENABLE = 0b00000100 # Enable bit

# Timing constants
E_PULSE = 0.0005
E_DELAY = 0.0005

class lcd_i2c():
    def __init__(self, i2c_bus=1, i2c_addr=I2C_ADDR, lcd_width=LCD_WIDTH_20):
        #Open I2C interface
        #self._bus = smbus.SMBus(0)  # Rev 1 Pi uses 0
        self._bus = smbus.SMBus(i2c_bus) # Rev 2 Pi uses 1
        self._i2c_addr = i2c_addr
        self._lcd_width = lcd_width

    def lcd_init(self):
        # Initialise display
        self.lcd_byte(0x33, LCD_CMD) # 110011 Initialise
        self.lcd_byte(0x32, LCD_CMD) # 110010 Initialise
        self.lcd_byte(0x06, LCD_CMD) # 000110 Cursor move direction
        self.lcd_byte(0x0C, LCD_CMD) # 001100 Display On,Cursor Off, Blink Off
        self.lcd_byte(0x28, LCD_CMD) # 101000 Data length, number of lines, font size
        self.lcd_byte(0x01, LCD_CMD) # 000001 Clear display
        time.sleep(E_DELAY)

    def lcd_byte(self, bits, mode):
        # Send byte to data pins
        # bits = the data
        # mode = 1 for data
        #        0 for command
        bits_high = mode | (bits & 0xF0) | LCD_BACKLIGHT
        bits_low = mode | ((bits<<4) & 0xF0) | LCD_BACKLIGHT

        # High bits
        self._bus.write_byte(self._i2c_addr, bits_high)
        self.lcd_toggle_enable(bits_high)

        # Low bits
        self._bus.write_byte(self._i2c_addr, bits_low)
        self.lcd_toggle_enable(bits_low)

    def lcd_toggle_enable(self, bits):
        # Toggle enable
        time.sleep(E_DELAY)
        self._bus.write_byte(self._i2c_addr, (bits | ENABLE))
        time.sleep(E_PULSE)
        self._bus.write_byte(self._i2c_addr, (bits & ~ENABLE))
        time.sleep(E_DELAY)

    def lcd_string(self, message, line):
        # Send string to display
        message = message.ljust(self._lcd_width, " ")
        self.lcd_byte(line, LCD_CMD)

        for i in range(self._lcd_width):
            self.lcd_byte(ord(message[i]), LCD_CHR)

    def lcd_clear(self):
        self.lcd_byte(0x01, LCD_CMD) # 000001 Clear display
        time.sleep(E_DELAY)

    def turn_off(self):
        self._bus.write_byte(self._i2c_addr, 0x00)
